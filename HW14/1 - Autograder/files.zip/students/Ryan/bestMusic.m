function strBest = bestMusic(~)
    strBest = 'Genesis';
end