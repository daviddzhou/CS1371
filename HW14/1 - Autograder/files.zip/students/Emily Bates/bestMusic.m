function strBest = bestMusic(cellVar)
    strBest = cellVar{1};
end